# پروژه اندروید Chapman

فایل HTML اصلی داخل `app/src/main/assets/index.html` قرار دارد و برنامه با Java و WebView آن را به شکل اپ اندروید اجرا می‌کند. اسکریپت Python فقط ساخت APK را اجرا می‌کند؛ Python داخل خود اپ لازم نیست.

## ساخت APK با Android Studio
1. Android Studio و Android SDK را نصب کنید.
2. پوشه `ChapmanAndroid` را در Android Studio باز کنید.
3. صبر کنید Gradle Sync تمام شود.
4. از منوی **Build > Build APK(s)** استفاده کنید.
5. فایل خروجی معمولاً در `app/build/outputs/apk/debug/app-debug.apk` است.

## ساخت با Python
اگر Gradle و Android SDK از قبل نصب و تنظیم شده‌اند، از ترمینال داخل همین پوشه اجرا کنید:

```bash
python3 build_apk.py
```

## نکته
بازی فعلی برای بارگذاری موتور Pac-Man و فونت به اینترنت نیاز دارد. برای کارکرد کامل، هنگام اجرای برنامه اینترنت دستگاه روشن باشد.
