#!/usr/bin/env python3
"""Build the debug APK using an installed Gradle + Android SDK."""
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
if not shutil.which("gradle"):
    print("Gradle was not found. Open this folder in Android Studio and let it sync, then Build > Build APK(s).")
    sys.exit(2)
result = subprocess.run(["gradle", "--no-daemon", "assembleDebug"], cwd=root)
if result.returncode == 0:
    apk = root / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk"
    print(f"APK created: {apk}" if apk.exists() else "Build finished; check app/build/outputs/apk/debug/")
sys.exit(result.returncode)
